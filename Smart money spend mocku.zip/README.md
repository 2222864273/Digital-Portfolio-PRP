
  # Smart money spend mocku

  This is a code bundle for Smart money spend mocku. The original project is available at https://www.figma.com/design/TqyHfRotRDNaMgRtEIwMYK/Smart-money-spend-mocku.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  