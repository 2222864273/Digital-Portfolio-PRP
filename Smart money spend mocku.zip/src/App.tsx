import { useState } from 'react';
import { OnboardingScreen } from './components/OnboardingScreen';
import { LoginScreen } from './components/LoginScreen';
import { RegisterScreen } from './components/RegisterScreen';
import { AboutScreen } from './components/AboutScreen';
import { ContactScreen } from './components/ContactScreen';
import { DashboardScreen } from './components/DashboardScreen';
import { LayoutDashboard, Info, MessageCircle, Home, LogOut } from 'lucide-react';
import logo from 'figma:asset/c964029090780ac62ec64d9d60411d8d65e33305.png';

type Screen = 'onboarding' | 'login' | 'register' | 'dashboard' | 'about' | 'contact';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('onboarding');
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  const navigateToScreen = (screen: Screen) => {
    setCurrentScreen(screen);
  };

  const handleLogin = () => {
    setIsAuthenticated(true);
    setCurrentScreen('dashboard');
  };

  const handleRegister = () => {
    setIsAuthenticated(true);
    setCurrentScreen('dashboard');
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setCurrentScreen('login');
  };

  const handleOnboardingComplete = () => {
    setCurrentScreen('login');
  };

  // Screens where taskbar should be hidden
  const hideTaskbar = ['onboarding', 'login', 'register'].includes(currentScreen);

  return (
    <div className="min-h-screen bg-background text-foreground pb-20">
      {/* Header with Logo - Show on all pages */}
      <header className="sticky top-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <button 
            onClick={() => isAuthenticated ? navigateToScreen('dashboard') : null}
            className="flex items-center gap-3 hover:opacity-80 transition-opacity"
          >
            <img src={logo} alt="SmartSpend Logo" className="h-10 w-auto" />
          </button>

          {/* Logout Button - Only show when authenticated */}
          {isAuthenticated && (
            <button
              onClick={handleLogout}
              className="flex items-center gap-2 px-3 py-2 text-muted-foreground hover:text-accent transition-colors rounded-lg hover:bg-secondary"
              title="Logout"
            >
              <LogOut className="w-5 h-5" />
              <span className="text-sm hidden sm:inline">Logout</span>
            </button>
          )}
        </div>
      </header>

      {/* Main Content - Single Screen Display */}
      <main className="min-h-screen">
        {currentScreen === 'onboarding' && (
          <OnboardingScreen onNext={handleOnboardingComplete} />
        )}

        {currentScreen === 'login' && (
          <LoginScreen 
            onLogin={handleLogin}
            onNavigateToRegister={() => navigateToScreen('register')}
          />
        )}

        {currentScreen === 'register' && (
          <RegisterScreen 
            onRegister={handleRegister}
            onNavigateToLogin={() => navigateToScreen('login')}
          />
        )}
        
        {currentScreen === 'dashboard' && (
          <DashboardScreen />
        )}
        
        {currentScreen === 'about' && (
          <AboutScreen onBack={() => navigateToScreen('dashboard')} />
        )}
        
        {currentScreen === 'contact' && (
          <ContactScreen onBack={() => navigateToScreen('dashboard')} />
        )}
      </main>

      {/* Bottom Navigation Taskbar - Hide on onboarding, login, register */}
      {!hideTaskbar && (
        <nav className="fixed bottom-0 left-0 right-0 z-50 bg-background/95 backdrop-blur-sm border-t border-border">
          <div className="container mx-auto px-4 py-3">
            <div className="flex items-center justify-around max-w-lg mx-auto">
              {/* Home Tab */}
              <button
                onClick={() => navigateToScreen('dashboard')}
                className={`flex flex-col items-center gap-1 px-3 py-2 rounded-lg transition-all duration-200 ${
                  currentScreen === 'dashboard'
                    ? 'bg-accent/10 text-accent'
                    : 'text-muted-foreground hover:text-foreground hover:bg-secondary'
                }`}
              >
                <Home className={`w-6 h-6 ${currentScreen === 'dashboard' ? 'text-accent' : ''}`} />
                <span className="text-xs">Home</span>
              </button>

              {/* Dashboard Tab */}
              <button
                onClick={() => navigateToScreen('dashboard')}
                className={`flex flex-col items-center gap-1 px-3 py-2 rounded-lg transition-all duration-200 ${
                  currentScreen === 'dashboard'
                    ? 'bg-accent/10 text-accent'
                    : 'text-muted-foreground hover:text-foreground hover:bg-secondary'
                }`}
              >
                <LayoutDashboard className={`w-6 h-6 ${currentScreen === 'dashboard' ? 'text-accent' : ''}`} />
                <span className="text-xs">Dashboard</span>
              </button>

              {/* About Tab */}
              <button
                onClick={() => navigateToScreen('about')}
                className={`flex flex-col items-center gap-1 px-3 py-2 rounded-lg transition-all duration-200 ${
                  currentScreen === 'about'
                    ? 'bg-accent/10 text-accent'
                    : 'text-muted-foreground hover:text-foreground hover:bg-secondary'
                }`}
              >
                <Info className={`w-6 h-6 ${currentScreen === 'about' ? 'text-accent' : ''}`} />
                <span className="text-xs">About</span>
              </button>

              {/* Contact Tab */}
              <button
                onClick={() => navigateToScreen('contact')}
                className={`flex flex-col items-center gap-1 px-3 py-2 rounded-lg transition-all duration-200 ${
                  currentScreen === 'contact'
                    ? 'bg-accent/10 text-accent'
                    : 'text-muted-foreground hover:text-foreground hover:bg-secondary'
                }`}
              >
                <MessageCircle className={`w-6 h-6 ${currentScreen === 'contact' ? 'text-accent' : ''}`} />
                <span className="text-xs">Contact</span>
              </button>
            </div>
          </div>
        </nav>
      )}
    </div>
  );
}