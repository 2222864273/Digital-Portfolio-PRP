import { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Progress } from './ui/progress';
import { Wallet, Target, TrendingUp, BookOpen, Plus, Eye, ChevronRight } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function DashboardScreen() {
  const [currentTip, setCurrentTip] = useState(0);

  const budgetData = {
    totalBudget: 1500,
    spent: 850,
    remaining: 650,
    categories: [
      { name: 'Food', spent: 320, budget: 500, color: '#FFFF00' },
      { name: 'Transport', spent: 150, budget: 200, color: '#CCCCCC' },
      { name: 'Entertainment', spent: 180, budget: 300, color: '#B0B0B0' },
      { name: 'Books', spent: 200, budget: 250, color: '#333333' }
    ]
  };

  const savingsGoals = [
    { 
      name: 'Emergency Fund', 
      current: 450, 
      target: 1000, 
      progress: 45,
      color: '#FFFF00'
    },
    { 
      name: 'Spring Break', 
      current: 280, 
      target: 800, 
      progress: 35,
      color: '#CCCCCC'
    },
    { 
      name: 'New Laptop', 
      current: 650, 
      target: 1200, 
      progress: 54,
      color: '#B0B0B0'
    }
  ];

  const financialTips = [
    {
      title: "Track Daily Expenses",
      content: "Log every purchase, no matter how small. Small expenses add up quickly!",
      category: "Budgeting"
    },
    {
      title: "50/30/20 Rule",
      content: "Spend 50% on needs, 30% on wants, and save 20% for your future.",
      category: "Saving"
    },
    {
      title: "Student Discounts",
      content: "Always ask for student discounts. Many businesses offer them even if not advertised.",
      category: "Spending"
    },
    {
      title: "Cook at Home",
      content: "Meal prep and cooking at home can save you hundreds each month.",
      category: "Food"
    }
  ];

  return (
    <div className="min-h-screen bg-background text-foreground p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6 pt-4">
        <h2>Dashboard</h2>
        <Button
          size="icon"
          className="smartspend-button w-10 h-10"
        >
          <Plus className="w-5 h-5" />
        </Button>
      </div>

      {/* Budget Overview */}
      <Card className="smartspend-card mb-6">
        <div className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-2">
              <Wallet className="w-5 h-5 text-accent" />
              <h3>Budget Tracker</h3>
            </div>
            <Button variant="ghost" size="icon">
              <Eye className="w-4 h-4" />
            </Button>
          </div>
          
          <div className="mb-4">
            <div className="flex justify-between mb-2">
              <span className="text-muted-foreground">Monthly Budget</span>
              <span>{budgetData.totalBudget}</span>
            </div>
            <Progress 
              value={(budgetData.spent / budgetData.totalBudget) * 100} 
              className="mb-2"
            />
            <div className="flex justify-between">
              <span className="text-accent">Spent: {budgetData.spent}</span>
              <span className="text-foreground">Remaining: {budgetData.remaining}</span>
            </div>
          </div>

          <div className="space-y-3">
            {budgetData.categories.map((category, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-secondary rounded-lg">
                <span>{category.name}</span>
                <div className="text-right">
                  <div className="text-sm text-muted-foreground">
                    {category.spent} / {category.budget}
                  </div>
                  <div className="w-16 h-1 bg-muted rounded-full mt-1">
                    <div 
                      className="h-full bg-accent rounded-full transition-all duration-200"
                      style={{ width: `${(category.spent / category.budget) * 100}%` }}
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </Card>

      {/* Savings Goals */}
      <Card className="smartspend-card mb-6">
        <div className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-2">
              <Target className="w-5 h-5 text-accent" />
              <h3>Savings Goals</h3>
            </div>
            <Button variant="ghost" size="icon">
              <Plus className="w-4 h-4" />
            </Button>
          </div>
          
          <div className="space-y-4">
            {savingsGoals.map((goal, index) => (
              <div key={index} className="p-4 bg-secondary rounded-lg">
                <div className="flex justify-between items-center mb-2">
                  <h4>{goal.name}</h4>
                  <span className="text-sm text-muted-foreground">
                    {goal.progress}%
                  </span>
                </div>
                <Progress value={goal.progress} className="mb-2" />
                <div className="flex justify-between">
                  <span className="text-accent">{goal.current}</span>
                  <span className="text-muted-foreground">of {goal.target}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </Card>

      {/* Spending Insights */}
      <Card className="smartspend-card mb-6">
        <div className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-2">
              <TrendingUp className="w-5 h-5 text-accent" />
              <h3>Spending Insights</h3>
            </div>
            <Button variant="ghost" size="icon">
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
          
          <div className="mb-4 rounded-2xl overflow-hidden">
            <ImageWithFallback 
              src="https://images.unsplash.com/photo-1633158829556-6ea20ad39b4f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzYXZpbmdzJTIwZ29hbCUyMHByb2dyZXNzJTIwY2hhcnR8ZW58MXx8fHwxNzU5MjcyNjA1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
              alt="Savings and spending analytics chart"
              className="w-full h-32 object-cover"
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center p-3 bg-secondary rounded-lg">
              <div className="text-accent">42%</div>
              <div className="text-sm text-muted-foreground">Food & Dining</div>
            </div>
            <div className="text-center p-3 bg-secondary rounded-lg">
              <div className="text-accent">23%</div>
              <div className="text-sm text-muted-foreground">Transport</div>
            </div>
          </div>
        </div>
      </Card>

      {/* Financial Tips Carousel */}
      <Card className="smartspend-card">
        <div className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-2">
              <BookOpen className="w-5 h-5 text-accent" />
              <h3>Financial Tips</h3>
            </div>
            <span className="text-sm text-muted-foreground">
              {currentTip + 1} / {financialTips.length}
            </span>
          </div>
          
          <div className="mb-4">
            <div className="bg-secondary rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <h4>{financialTips[currentTip].title}</h4>
                <span className="text-xs bg-accent text-accent-foreground px-2 py-1 rounded-full">
                  {financialTips[currentTip].category}
                </span>
              </div>
              <p className="text-muted-foreground">
                {financialTips[currentTip].content}
              </p>
            </div>
          </div>
          
          <div className="flex justify-center space-x-2">
            {financialTips.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentTip(index)}
                className={`w-2 h-2 rounded-full transition-colors ${
                  index === currentTip ? 'bg-accent' : 'bg-muted'
                }`}
              />
            ))}
          </div>
        </div>
      </Card>
    </div>
  );
}