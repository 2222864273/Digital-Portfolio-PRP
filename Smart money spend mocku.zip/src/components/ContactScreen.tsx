import { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Label } from './ui/label';
import { ArrowLeft, MessageCircle, Mail, HelpCircle, Send } from 'lucide-react';

export function ContactScreen({ onBack }: { onBack: () => void }) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission
    console.log('Form submitted:', formData);
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const supportOptions = [
    {
      icon: <HelpCircle className="w-6 h-6 text-accent" />,
      title: "Help Center",
      description: "Browse FAQs and guides",
      action: "View FAQs"
    },
    {
      icon: <MessageCircle className="w-6 h-6 text-accent" />,
      title: "Live Chat",
      description: "Chat with our support team",
      action: "Start Chat"
    },
    {
      icon: <Mail className="w-6 h-6 text-accent" />,
      title: "Email Support",
      description: "hello@smartspend.app",
      action: "Send Email"
    }
  ];

  return (
    <div className="min-h-screen bg-background text-foreground p-6">
      {/* Header */}
      <div className="flex items-center mb-6 pt-4">
        <Button
          variant="ghost"
          size="icon"
          onClick={onBack}
          className="mr-3 text-foreground hover:bg-secondary"
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <h2>Contact & Support</h2>
      </div>

      {/* Support Options */}
      <div className="mb-6">
        <h3 className="mb-4">We're here to help</h3>
        <div className="space-y-3">
          {supportOptions.map((option, index) => (
            <Card 
              key={index}
              className="smartspend-card cursor-pointer"
            >
              <div className="p-4 flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-secondary rounded-lg flex items-center justify-center">
                    {option.icon}
                  </div>
                  <div>
                    <h4>{option.title}</h4>
                    <p className="text-muted-foreground">{option.description}</p>
                  </div>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  className="border-accent text-accent hover:bg-accent hover:text-accent-foreground"
                >
                  {option.action}
                </Button>
              </div>
            </Card>
          ))}
        </div>
      </div>

      {/* Contact Form */}
      <Card className="smartspend-card">
        <div className="p-6">
          <h3 className="mb-4 text-accent">Send us a message</h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Name</Label>
              <Input
                id="name"
                type="text"
                value={formData.name}
                onChange={(e) => handleInputChange('name', e.target.value)}
                className="smartspend-input"
                placeholder="Your full name"
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => handleInputChange('email', e.target.value)}
                className="smartspend-input"
                placeholder="your.email@student.edu"
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="message">Message</Label>
              <Textarea
                id="message"
                value={formData.message}
                onChange={(e) => handleInputChange('message', e.target.value)}
                className="smartspend-input min-h-[120px] resize-none"
                placeholder="How can we help you? Share your feedback, questions, or suggestions..."
                required
              />
            </div>
            
            <Button
              type="submit"
              className="smartspend-button w-full"
            >
              <Send className="w-4 h-4 mr-2" />
              Send Message
            </Button>
          </form>
        </div>
      </Card>

      {/* Footer */}
      <div className="mt-6 text-center">
        <p className="text-muted-foreground">
          We typically respond within 24 hours
        </p>
      </div>
    </div>
  );
}