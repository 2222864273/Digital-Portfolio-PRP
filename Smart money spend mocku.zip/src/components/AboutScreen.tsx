import { Card } from './ui/card';
import { Button } from './ui/button';
import { ArrowLeft, Users, Heart, Lightbulb, Shield, Zap } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function AboutScreen({ onBack }: { onBack: () => void }) {
  const values = [
    {
      icon: <Zap className="w-6 h-6 text-accent" />,
      title: "Simplicity",
      description: "Making money management effortless for students"
    },
    {
      icon: <Users className="w-6 h-6 text-accent" />,
      title: "Empowerment",
      description: "Giving students control over their financial future"
    },
    {
      icon: <Lightbulb className="w-6 h-6 text-accent" />,
      title: "Innovation",
      description: "Smart features that adapt to student lifestyles"
    },
    {
      icon: <Heart className="w-6 h-6 text-accent" />,
      title: "Community",
      description: "Building a supportive network of financially smart students"
    },
    {
      icon: <Shield className="w-6 h-6 text-accent" />,
      title: "Trust",
      description: "Secure, transparent, and reliable financial tools"
    }
  ];

  return (
    <div className="min-h-screen bg-background text-foreground p-6">
      {/* Header */}
      <div className="flex items-center mb-6 pt-4">
        <Button
          variant="ghost"
          size="icon"
          onClick={onBack}
          className="mr-3 text-foreground hover:bg-secondary"
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <h2>About SmartSpend</h2>
      </div>

      {/* Mission Section */}
      <Card className="smartspend-card mb-6">
        <div className="p-6">
          <h3 className="mb-4 text-accent">Our Mission</h3>
          <p className="mb-4">
            Empowering students to take control of their money with smart, 
            intuitive tools designed for the modern student lifestyle.
          </p>
          <p className="text-muted-foreground">
            We believe financial wellness should be accessible, engaging, 
            and tailored to your unique needs as a student.
          </p>
        </div>
      </Card>

      {/* Team Image - Diverse Student Energy */}
      <div className="mb-6 rounded-2xl overflow-hidden">
        <ImageWithFallback 
          src="https://images.unsplash.com/photo-1717185358815-870a1f963465?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYXBweSUyMGRpdmVyc2UlMjB1bml2ZXJzaXR5JTIwc3R1ZGVudHMlMjBsYXVnaGluZyUyMHRvZ2V0aGVyJTIwbXVsdGljdWx0dXJhbHxlbnwxfHx8fDE3NTkyNzM3NzJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
          alt="Diverse group of happy university students from all backgrounds"
          className="w-full h-40 object-cover"
        />
      </div>

      {/* Values Section */}
      <div className="mb-6">
        <h3 className="mb-4 text-accent">Our Values</h3>
        <div className="space-y-3">
          {values.map((value, index) => (
            <Card 
              key={index}
              className="smartspend-card cursor-pointer"
            >
              <div className="p-4 flex items-start space-x-3">
                <div className="flex-shrink-0 w-10 h-10 bg-secondary rounded-lg flex items-center justify-center">
                  {value.icon}
                </div>
                <div className="flex-1">
                  <h4 className="mb-1">{value.title}</h4>
                  <p className="text-muted-foreground">{value.description}</p>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>

      {/* Story Section */}
      <Card className="smartspend-card">
        <div className="p-6">
          <h3 className="mb-4 text-accent">Our Story</h3>
          <p className="mb-4">
            Started by students, for students. We understand the unique 
            financial challenges of student life - from managing tight budgets 
            to saving for future goals.
          </p>
          <p className="text-muted-foreground">
            SmartSpend was born from the need for a financial app that truly 
            gets student life, offering practical tools without the complexity.
          </p>
        </div>
      </Card>
    </div>
  );
}