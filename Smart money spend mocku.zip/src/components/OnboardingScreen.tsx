import { useState } from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { ChevronRight, DollarSign, Target, TrendingUp, BookOpen } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function OnboardingScreen({ onNext }: { onNext: () => void }) {
  const [currentSlide, setCurrentSlide] = useState(0);

  const features = [
    {
      icon: <DollarSign className="w-8 h-8 text-accent" />,
      title: "Smart Budget Tracking",
      description: "Track your spending with intelligent categorization and real-time updates."
    },
    {
      icon: <Target className="w-8 h-8 text-accent" />,
      title: "Savings Goals",
      description: "Set and achieve your financial goals with personalized milestone tracking."
    },
    {
      icon: <TrendingUp className="w-8 h-8 text-accent" />,
      title: "Spending Insights",
      description: "Get detailed analytics on your spending patterns and habits."
    },
    {
      icon: <BookOpen className="w-8 h-8 text-accent" />,
      title: "Financial Tips",
      description: "Learn money management with curated tips for students."
    }
  ];

  return (
    <div className="min-h-screen bg-background text-foreground p-6 flex flex-col">
      {/* Header */}
      <div className="text-center mb-8 pt-4">
        <h1 className="mb-2">SmartSpend</h1>
        <p className="text-muted-foreground">Smart way to spend & save</p>
      </div>

      {/* Hero Image */}
      <div className="mb-8 rounded-2xl overflow-hidden">
        <ImageWithFallback 
          src="https://images.unsplash.com/photo-1633504214759-e1013f422ed7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdHVkZW50JTIwbW9uZXklMjBidWRnZXRpbmclMjBtb2JpbGUlMjBwaG9uZXxlbnwxfHx8fDE3NTkyNzI1OTl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
          alt="Student budgeting on mobile phone"
          className="w-full h-48 object-cover"
        />
      </div>

      {/* Feature Carousel */}
      <div className="flex-1 mb-8">
        <Card className="smartspend-card h-full">
          <div className="text-center p-6">
            <div className="mb-4 flex justify-center">
              {features[currentSlide].icon}
            </div>
            <h3 className="mb-3">{features[currentSlide].title}</h3>
            <p className="text-muted-foreground mb-6">
              {features[currentSlide].description}
            </p>
            
            {/* Slide Indicators */}
            <div className="flex justify-center space-x-2 mb-6">
              {features.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentSlide(index)}
                  className={`w-2 h-2 rounded-full transition-colors ${
                    index === currentSlide ? 'bg-accent' : 'bg-muted'
                  }`}
                />
              ))}
            </div>
          </div>
        </Card>
      </div>

      {/* Navigation */}
      <div className="flex space-x-3">
        <Button
          variant="outline"
          onClick={() => setCurrentSlide((prev) => (prev + 1) % features.length)}
          className="flex-1 border-accent text-accent hover:bg-accent hover:text-accent-foreground"
        >
          Next Feature
          <ChevronRight className="w-4 h-4 ml-1" />
        </Button>
        <Button
          onClick={onNext}
          className="smartspend-button flex-1"
        >
          Get Started
        </Button>
      </div>
    </div>
  );
}