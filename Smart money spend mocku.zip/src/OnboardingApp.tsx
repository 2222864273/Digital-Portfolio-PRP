import { OnboardingScreen } from './components/OnboardingScreen';

export default function OnboardingApp() {
  const handleNext = () => {
    console.log('Get Started clicked - ready to proceed to dashboard');
  };

  return (
    <div className="min-h-screen bg-background">
      <OnboardingScreen onNext={handleNext} />
    </div>
  );
}