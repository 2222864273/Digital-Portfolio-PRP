import { AboutScreen } from './components/AboutScreen';

export default function AboutApp() {
  const handleBack = () => {
    console.log('Back button clicked - navigation handled');
  };

  return (
    <div className="min-h-screen bg-background">
      <AboutScreen onBack={handleBack} />
    </div>
  );
}