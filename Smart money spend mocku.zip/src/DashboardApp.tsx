import { DashboardScreen } from './components/DashboardScreen';

export default function DashboardApp() {
  const handleBack = () => {
    console.log('Back button clicked - navigation handled');
  };

  return (
    <div className="min-h-screen bg-background">
      <DashboardScreen onBack={handleBack} />
    </div>
  );
}