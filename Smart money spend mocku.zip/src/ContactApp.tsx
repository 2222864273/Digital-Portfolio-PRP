import { ContactScreen } from './components/ContactScreen';

export default function ContactApp() {
  const handleBack = () => {
    console.log('Back button clicked - navigation handled');
  };

  return (
    <div className="min-h-screen bg-background">
      <ContactScreen onBack={handleBack} />
    </div>
  );
}